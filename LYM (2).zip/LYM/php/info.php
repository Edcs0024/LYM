<?php
phpinfo();
?>

